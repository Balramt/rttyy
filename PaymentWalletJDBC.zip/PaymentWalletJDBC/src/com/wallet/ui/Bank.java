package com.wallet.ui;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

import com.wallet.model.Transactions;
import com.wallet.service.WalletServices;
import com.wallet.service.WalletServicesImpl;

public class Bank {

	private static long mobile;
	private static LocalDate dob;

	public static void main(String[] args) {
		WalletServices service = new WalletServicesImpl();

		System.out.println("Welcome to YASH Bank");
		Scanner sc = new Scanner(System.in);
		boolean flag = true;
		while (flag) {
			System.out.println(" ");
			System.out.println(" ");
			System.out.println(
					"Enter your choice\n1. Create Account\n2. Show Balance\n3. Deposit Money \n4. Withdraw Money\n5. Fund Transfer\n6. Print Transactions\n7. Exit");
			int choice = sc.nextInt();

			switch (choice) {
			case 1:
				System.out.println("Enter your First name:      ");
				String fname = sc.next();
				System.out.println("Enter your Last name:      ");
				String lname = sc.next();
				String name = fname + lname;
				while (service.isAlpha(name) == false) {
					System.out.println("Enter your First name correctly:      ");
					fname = sc.next();
					System.out.println("Enter your Last name correctly:      ");
					lname = sc.next();
					name = fname + lname;
				}
				name = fname + " " + lname;

				System.out.println("Enter your Mobile No:      ");
				String mobile = sc.next();
				while ((service.isMobileNo(mobile) && mobile.length() == 10) == false) {
					System.out.println("Sorry!!!! You have entered invalid mobile number. Try again...");
					mobile = sc.next();
				}

				System.out.println("Enter your Email ID:      ");
				String email = sc.next();
				while (service.isEmail(email) == false) {
					System.out.println("Please enter your Email ID correctly:      ");
					email = sc.next();

				}
				
				try {
					System.out.println("Enter your Date of birth in (yyyy-MM-dd) format:      ");
					dob = LocalDate.parse(sc.next());
				}catch (Exception e) {
					System.out.println("Wrong Input! Please try again.");
					break;
				}
				
				int result = service.createUser(name, mobile, email, dob);
				if (result!=0) {

					System.out.println("*******************************************");
					System.out.println("-------------------------------------------");
					System.out.println("Congratulations!!! Your account is created.");
					System.out.println("-------------------------------------------");
					System.out.println("*******************************************");
					System.out.println("Your account number is-             "+result);
					System.out.println("-------------------------------------------");
					System.out.println("*******************************************");

				} 
				else {
					System.out.println("Account Creation failed");
				}
				break;
			case 2:
				System.out.println("Enter account number:    ");
				int acc = sc.nextInt();
				while(service.checkAcc(acc) == false) {
					System.out.println("Enter correct account number:    ");
					acc = sc.nextInt();
				}
				System.out.println("Your current balance is : " + service.showBalance(acc));
				break;
			case 3:
				System.out.println("Enter account number:    ");
				int acco = sc.nextInt();

				while(service.checkAcc(acco) == false) {
					System.out.println("Enter correct account number:    ");
					acco = sc.nextInt();
				}
				System.out.println("Enter amount to be deposited:    ");
				double depositAmount = sc.nextDouble();
				System.out.println("Your updated balance is: " + service.depositBalance(acco, depositAmount));
				break;
			case 4:
				System.out.println("Enter account number:    ");
				int accon = sc.nextInt();
				while(service.checkAcc(accon) == false) {
					System.out.println("Enter correct account number:    ");
					accon = sc.nextInt();
				}
				System.out.println("Enter amount to be withdrawn:    ");
				double withdrawAmount = sc.nextDouble();
				while (service.checkBal(accon, withdrawAmount) == false) {
					System.out.println(
							"There is not enough balance.\n Please enter a suitable amount to be withdrawn:    ");
					withdrawAmount = sc.nextDouble();
				}
				System.out.println("Your updated balance is: " + service.withdrawBalance(accon, withdrawAmount));
				break;
			case 5:
				System.out.println("Enter sender's account number:    ");
				int senderAcc = sc.nextInt();
				while(service.checkAcc(senderAcc) == false) {
					System.out.println("Enter the sender's account number correctly:    ");
					senderAcc = sc.nextInt();
				}
				
				System.out.println("Enter reciever's account number:    ");
				int recieverAcc = sc.nextInt();
				
				while(service.checkAcc(recieverAcc) == false) {
					System.out.println("Enter the reciever's account number correctly:    ");
					recieverAcc= sc.nextInt();
				}
				
				System.out.println("Enter amount to be transferred:    ");
				double transferAmount = sc.nextDouble();
				while (service.checkBal(senderAcc,transferAmount) == false) {
					System.out.println(
							"There is not enough balance.\n Please enter a suitable amount to be withdrawn:    ");
					transferAmount= sc.nextDouble();
				}
				
				boolean fundTransferResult = service.fundTransfer(senderAcc, recieverAcc, transferAmount);
				if (fundTransferResult) {
					System.out.println(
							"The amount " + transferAmount + " is added from " + senderAcc + " to " + recieverAcc);
				} else {
					System.out.println("Fund Transfer failed");
				}
				break;
			case 6:
				System.out.println("Enter account number to fetch transactions:    ");
				int transactionsOfAccount = sc.nextInt();
				while(service.checkAcc(transactionsOfAccount) == false) {
					System.out.println("Enter a correct account number:    ");
					transactionsOfAccount = sc.nextInt();
				}
				List<Transactions> transactions = service.readTransaction(transactionsOfAccount);
				transactions.stream().forEach(trans -> System.out.println(trans));
				break;
			case 7:
				flag = false;
				System.out.println("Bye Bye!!!");
				break;
			default:
				System.out.println("Enter input correctly");

			}
		}
	}

}
