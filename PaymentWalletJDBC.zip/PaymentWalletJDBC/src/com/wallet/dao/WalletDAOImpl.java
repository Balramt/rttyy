package com.wallet.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.wallet.model.Transactions;
import com.wallet.model.User;
import com.wallet.util.BankCollection;

public class WalletDAOImpl implements WalletDAO {

	private BankCollection dbUtil = null;
	int accountno;
	int transactionNo;
	String accquery;
	String traquery;

	public WalletDAOImpl() {
		dbUtil = BankCollection.getInstance();
	}

	@Override
	public int addAccount(User user) {
		try {
			
			Connection connection = dbUtil.openDatabaseConnection();

			Statement stmt1 = connection.createStatement();
			try{
				accquery = "select max(accountno) as acc_no from users";
				ResultSet rs = stmt1.executeQuery(accquery);
				if(rs.next()){
						accountno = rs.getInt("acc_no");
					}
				}catch (Exception e) {
				accountno=99999;
			}
			++accountno;
			if(accountno<10){
			accountno+=100000;
			}
//			System.out.println(accountno);
			
			String query = "Insert into users(accountno,name,currentbalance,mobileno,email,DOB) values(?,?,?,?,?,?)";
			PreparedStatement pstmt = connection.prepareStatement(query);
			pstmt.setInt(1, accountno);
			pstmt.setString(2, user.getName());
			pstmt.setDouble(3, user.getCurrentBalance());
			pstmt.setString(4, user.getMobileNo());
			pstmt.setString(5, user.getEmail());

			pstmt.setDate(6, Date.valueOf(user.getDob()));
			int result = pstmt.executeUpdate();
			dbUtil.closeDatabaseConnection();
			if (result != 0) {
				return accountno;
			}
		}catch(ClassNotFoundException|

	SQLException e)
	{
		System.out.println("err");
	}return 0;
	}

	@Override
	public User readUserDetails(int account) {

		try {
			Connection connection = dbUtil.openDatabaseConnection();
			Statement stmt = connection.createStatement();

			String query = "select * from users where accountno=" + account;
			ResultSet rs = stmt.executeQuery(query);
			while (rs.next()) {

				int accountno = rs.getInt("accountno");
				String name = rs.getString("name");
				double currentbalance = rs.getDouble("currentbalance");
				String mobileno = rs.getString("mobileno");
				String email = rs.getString("email");
				LocalDate dob = rs.getDate("dob").toLocalDate();

				User user = new User(accountno, name, currentbalance, mobileno, email, dob);
				return user;

			}

		} catch (ClassNotFoundException | SQLException e) {
			System.out.println("err");
		}
		return null;

	}

	@Override
	public boolean updateUserDetails(User newUser) {

		try {
			Connection connection = dbUtil.openDatabaseConnection();

			String query = "Update users SET accountno=?,name=?,currentbalance=?,mobileno=?,email=?,DOB=? where accountno=?";
			PreparedStatement pstmt = connection.prepareStatement(query);

			pstmt.setInt(1, newUser.getAccountNo());
			pstmt.setString(2, newUser.getName());
			pstmt.setDouble(3, newUser.getCurrentBalance());
			pstmt.setString(4, newUser.getMobileNo());
			pstmt.setString(5, newUser.getEmail());

			pstmt.setDate(6, Date.valueOf(newUser.getDob()));
			pstmt.setInt(7, newUser.getAccountNo());

			int result = pstmt.executeUpdate();

			dbUtil.closeDatabaseConnection();

			if (result != 0) {
				return true;
			}
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println("err");
		}
		return false;

	}

	@Override
	public boolean addTransaction(Transactions transaction) {
		try {
			Connection connection = dbUtil.openDatabaseConnection();

			Statement stmt2 = connection.createStatement();
			try{
				traquery = "select max(transactionNo) as transaction_no from alltransactions";
				ResultSet rs = stmt2.executeQuery(traquery);
				if(rs.next()){
					transactionNo = rs.getInt("transaction_no");
					}
				}catch (Exception e) {
					transactionNo=99999;
			}
			
			++transactionNo;
			if(transactionNo<10){
				transactionNo+=100000;
				}

//
			
			String query = "Insert into alltransactions(sender,transactionNo,reciever,amount,transactiondate,comments) values(?,?,?,?,?,?)";
			PreparedStatement pstmt = connection.prepareStatement(query);

			pstmt.setInt(1, transaction.getSenderAccountNo());
			pstmt.setInt(2, transactionNo);
			pstmt.setInt(3, transaction.getRecieverAccountNo());
			pstmt.setDouble(4, transaction.getAmount());
			pstmt.setDate(5, Date.valueOf(transaction.getDate()));
			pstmt.setString(6, transaction.getComment());
			int result = pstmt.executeUpdate();

			dbUtil.closeDatabaseConnection();
			if (result != 0) {
				return true;
			}
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println("err");
		}
		return false;
	}

	@Override
	public List<Transactions> readTransactionDetails(int accountNo) {

		try {
			Connection connection = dbUtil.openDatabaseConnection();
			Statement stmt = connection.createStatement();
			String query = "select * from allTransactions";
			List<Transactions> list = new ArrayList<Transactions>();
			ResultSet rs = stmt.executeQuery(query);

			while (rs.next()) {

				int sender = rs.getInt("sender");
				int transactionNo = rs.getInt("transactionNo");
				int reciever = rs.getInt("reciever");
				double amount = rs.getDouble("reciever");
				LocalDate transactiondate = rs.getDate("transactiondate").toLocalDate();
				String comments = rs.getString("comments");
				Transactions transactions = new Transactions(sender, transactionNo, reciever, amount, transactiondate,
						comments);
				list.add(transactions);

			}
			return list;
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println("err");
		}
		return null;
	}

}
