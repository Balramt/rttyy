package com.wallet.dao;

import java.util.List;

import com.wallet.model.Transactions;
import com.wallet.model.User;

public interface WalletDAO {
	 public int addAccount(User user);
	 public User readUserDetails(int account);
	 public boolean updateUserDetails(User newUser);
	 public boolean addTransaction(Transactions transaction);
	 public List<Transactions> readTransactionDetails(int accountNo);
}
