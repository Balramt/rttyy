package com.wallet.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class BankCollection {
	
	
	private static Connection connection;
	private static BankCollection object= new BankCollection();
	
	private BankCollection(){
	}
		//nobody can create object of this class,,,singleton
		
	public synchronized static BankCollection getInstance(){
		return object;
	}
	
	
public Connection openDatabaseConnection(String username,String password) throws ClassNotFoundException, SQLException{
		
		
		Class.forName("oracle.jdbc.driver.OracleDriver");
		connection = DriverManager.getConnection("jdbc:oracle:thin:@172.16.10.2:1521:orcl",username,password);
		return connection;
	}
public Connection openDatabaseConnection() throws ClassNotFoundException, SQLException{
		
		
		Class.forName("oracle.jdbc.driver.OracleDriver");
		connection = DriverManager.getConnection("jdbc:oracle:thin:@172.16.10.2:1521:orcl","seed27","seed27");
		return connection;
	}
	
	public void closeDatabaseConnection() throws SQLException{
		if(connection!=null)
			connection.close();
		
	}

}
