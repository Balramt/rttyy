package com.wallet.service;

import java.time.LocalDate;
import java.util.List;

import com.wallet.model.Transactions;

public interface WalletServices {
	public int createUser(String name,String mobile,String email,LocalDate dob);
	public double showBalance(int accountNo);
	public double depositBalance(int accountNo,double amount);
	public double withdrawBalance(int accountNo,double amount);
	public boolean fundTransfer(int senderAccount,int recieverAccount,double amount);
	public List<Transactions> readTransaction(int sender);
	public boolean isAlpha(String name);
	public boolean isMobileNo(String input);
	public boolean isEmail(String email);
	public boolean checkAcc(int acc);
	public boolean checkBal(int acc,double withdrawAmount);
	

}
