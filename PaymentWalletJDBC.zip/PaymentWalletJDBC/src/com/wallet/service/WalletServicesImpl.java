package com.wallet.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.wallet.dao.WalletDAO;
import com.wallet.dao.WalletDAOImpl;
import com.wallet.model.Transactions;
import com.wallet.model.User;

public class WalletServicesImpl implements WalletServices {

	WalletDAO dao = new WalletDAOImpl();
	private static int accountNoCounter = 0;
	private static int transactionCounter = 0;

	@Override
	public int createUser(String name, String mobile, String email, LocalDate dob) {
		User user = new User(accountNoCounter, name, 0, mobile, email, dob);
//		accountNoCounter++;
//		System.out.println(user.getAccountNo());
		return dao.addAccount(user);
	}

	@Override
	public double showBalance(int accountNo) {
		User user = dao.readUserDetails(accountNo);
		return user.getCurrentBalance();
	}

	@Override
	public double depositBalance(int accountNo, double amount) {
		User user = dao.readUserDetails(accountNo);
		double balance = user.getCurrentBalance() + amount;
		user.setCurrentBalance(balance);
		dao.updateUserDetails(user);
		Transactions t = new Transactions(user.getAccountNo(), transactionCounter++, 0, amount, LocalDate.now(),
				"Deposited");
		dao.addTransaction(t);
		System.out.println(t);
		return balance;
	}

	@Override
	public double withdrawBalance(int accountNo, double amount) {
		User user = dao.readUserDetails(accountNo);
		double balance = user.getCurrentBalance() - amount;
		user.setCurrentBalance(balance);
		dao.updateUserDetails(user);
		Transactions t = new Transactions(user.getAccountNo(), transactionCounter++, 0, amount, LocalDate.now(),
				"Withdrawn");
		dao.addTransaction(t);

		return balance;
	}

	@Override
	public boolean fundTransfer(int senderAccount, int recieverAccount, double amount) {
		User sender = dao.readUserDetails(senderAccount);
		User reciever = dao.readUserDetails(recieverAccount);

		double senderBalance = sender.getCurrentBalance() - amount;

		double recieverBalance = reciever.getCurrentBalance() + amount;
		sender.setCurrentBalance(senderBalance);
		reciever.setCurrentBalance(recieverBalance);

		dao.updateUserDetails(sender);
		dao.updateUserDetails(reciever);
		Transactions t = new Transactions(senderAccount, transactionCounter, recieverAccount, amount, LocalDate.now(),
				"Fund Transferred");
		Transactions t2 = new Transactions(senderAccount, transactionCounter++, recieverAccount, amount,
				LocalDate.now(), "Fund Recieved");
		dao.addTransaction(t);
		dao.addTransaction(t2);

		if (sender.getCurrentBalance() == senderBalance && reciever.getCurrentBalance() == recieverBalance) {
			return true;
		}
		return false;
	}

	@Override
	public List<Transactions> readTransaction(int sender) {
		List<Transactions> allTransactions = dao.readTransactionDetails(sender);
		List<Transactions> relatedTransactions = new ArrayList<Transactions>();

		Iterator<Transactions> itr = allTransactions.iterator();
		while (itr.hasNext()) {
			Transactions transactions = itr.next();
			if (transactions.getSenderAccountNo() == sender || transactions.getRecieverAccountNo() == sender) {
				relatedTransactions.add(transactions);
			}
		}
		return relatedTransactions;
	}

	@Override
	public boolean isAlpha(String s) {
		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			if (!(c >= 'A' && c <= 'Z') && !(c >= 'a' && c <= 'z')) {
				return false;
			}
		}
		return true;
	}

	@Override
	public boolean isMobileNo(String input) {
		try {
			Long.parseLong(input);
		} catch (NumberFormatException | InputMismatchException ex) {
			return false;
		}
		return true;
	}

	@Override
	public boolean isEmail(String email) {
		Pattern pattern = Pattern.compile("[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}");
		Matcher mat = pattern.matcher(email);

		if (mat.matches()) {
			return true;
		}
		return false;
	}

	@Override
	public boolean checkAcc(int acc) {
		if (dao.readUserDetails(acc) == null) {
			return false;
		}
		return true;
	}

	@Override
	public boolean checkBal(int acc,double withdrawAmount) {
		if((dao.readUserDetails(acc).getCurrentBalance()) < withdrawAmount) {
			return false;
		}
		return true;
	}

}
