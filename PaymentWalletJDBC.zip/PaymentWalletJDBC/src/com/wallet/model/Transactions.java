package com.wallet.model;

import java.time.LocalDate;

public class Transactions {
	private int senderAccountNo;
	private int transactionNo;
	private int recieverAccountNo;
	private double amount;
	private LocalDate date;
	private String comment;
	public int getSenderAccountNo() {
		return senderAccountNo;
	}
	public void setSenderAccountNo(int senderAccountNo) {
		this.senderAccountNo = senderAccountNo;
	}
	public int getTransactionNo() {
		return transactionNo;
	}
	public void setTransactionNo(int transactionNo) {
		this.transactionNo = transactionNo;
	}
	public int getRecieverAccountNo() {
		return recieverAccountNo;
	}
	public void setRecieverAccountNo(int recieverAccountNo) {
		this.recieverAccountNo = recieverAccountNo;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	@Override
	public String toString() {
		return "Transactions [senderAccountNo=" + senderAccountNo + ", transactionNo=" + transactionNo
				+ ", recieverAccountNo=" + recieverAccountNo + ", amount=" + amount + ", date=" + date + ", comment="
				+ comment + "]";
	}
	public Transactions(int senderAccountNo, int transactionNo, int recieverAccountNo, double amount, LocalDate date,
			String comment) {
		super();
		this.senderAccountNo = senderAccountNo;
		this.transactionNo = transactionNo;
		this.recieverAccountNo = recieverAccountNo;
		this.amount = amount;
		this.date = date;
		this.comment = comment;
	}



}

