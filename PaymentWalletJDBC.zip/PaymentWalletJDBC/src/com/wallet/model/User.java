package com.wallet.model;

import java.time.LocalDate;

public class User {
	private int accountNo;
	private String name;
	private double currentBalance;
	private String mobileNo;
	private String email;
	private LocalDate dob;
	
	public User(int accountNo, String name, double currentBalance, String mobileNo, String email, LocalDate dob) {
		super();
		this.accountNo = accountNo;
		this.name = name;
		this.currentBalance = currentBalance;
		this.mobileNo = mobileNo;
		this.email = email;
		this.dob = dob;
	}

	@Override
	public String toString() {
		return "accountNo=" + accountNo + ", name=" + name + ", currentBalance=" + currentBalance + ", mobileNo="
				+ mobileNo + ", email=" + email + ", dob=" + dob;
	}

	public int getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getCurrentBalance() {
		return currentBalance;
	}

	public void setCurrentBalance(double currentBalance) {
		this.currentBalance = currentBalance;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}
	

}
